# Notes

## Useful Links

*  **Tables** 
    * Separate outer border and cell border - https://stackoverflow.com/questions/8889567/how-can-i-have-a-rounded-border-on-my-table-and-border-collapse-collapse
    * Borders only on the inside (CSS Tricks) - https://css-tricks.com/table-borders-inside/
